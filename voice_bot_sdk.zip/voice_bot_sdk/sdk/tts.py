# sdk/tts.py

import requests

class TTSEngine:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.deepgram.com/v1/text-to-speech"

    async def synthesize(self, text):
        headers = {
            "Authorization": f"Token {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = {"text": text}
        response = requests.post(self.base_url, headers=headers, json=payload)
        return response.content
