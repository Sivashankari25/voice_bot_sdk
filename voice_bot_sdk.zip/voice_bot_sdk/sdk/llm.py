# sdk/llm.py

import openai

class LLMEngine:
    def __init__(self, api_key, system_prompt):
        self.api_key = api_key
        self.system_prompt = system_prompt
        openai.api_key = self.api_key

    async def get_response(self, user_text):
        prompt = f"{self.system_prompt}\nUser: {user_text}\nAI:"
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=prompt,
            max_tokens=150
        )
        return response.choices[0].text.strip()
