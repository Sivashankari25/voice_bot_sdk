# sdk/stt.py

import requests
import json

class STTEngine:
    def __init__(self, api_key):
        self.api_key = api_key
        self.base_url = "https://api.deepgram.com/v1/listen"

    async def transcribe(self, audio_data):
        headers = {
            "Authorization": f"Token {self.api_key}",
            "Content-Type": "audio/wav"
        }
        response = requests.post(self.base_url, headers=headers, data=audio_data, stream=True)
        result = response.json()
        print(json.dumps(result, indent=2))  # Debug: Print the API response
        if 'channel' in result and 'alternatives' in result['channel']:
            return result['channel']['alternatives'][0]['transcript']
        else:
            raise ValueError("Unexpected response format")
