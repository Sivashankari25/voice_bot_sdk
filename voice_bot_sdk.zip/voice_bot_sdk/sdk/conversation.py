# sdk/conversation.py

import asyncio
import time
import wave
import io
from .stt import STTEngine
from .tts import TTSEngine
from .llm import LLMEngine

class ConversationManager:
    def __init__(self, stt_config, tts_config, llm_config):
        self.stt_engine = STTEngine(api_key=stt_config['api_key'])
        self.tts_engine = TTSEngine(api_key=tts_config['api_key'])
        self.llm_engine = LLMEngine(api_key=llm_config['api_key'], system_prompt=llm_config['system_prompt'])
        self.sample_rate = 16000  # Example value, adjust as needed

    async def handle_conversation(self, input_stream, output_stream):
        start_time = time.time()
        
        # Read audio from input stream
        num_frames = 1024  # or use the value you set in `frames_per_buffer`
        audio_data = input_stream.read(num_frames)
        
        # Convert audio data to WAV format if needed
        wav_audio_data = self.convert_pcm_to_wav(audio_data, self.sample_rate)
        
        # Convert speech to text
        stt_start_time = time.time()
        text = await self.stt_engine.transcribe(wav_audio_data)
        stt_duration = time.time() - stt_start_time
        
        # Get response from LLM
        llm_start_time = time.time()
        response_text = await self.llm_engine.get_response(text)
        llm_duration = time.time() - llm_start_time
        
        # Convert text to speech
        tts_start_time = time.time()
        audio_response = await self.tts_engine.synthesize(response_text)
        tts_duration = time.time() - tts_start_time
        
        # Stream audio response to output stream
        output_stream.write(audio_response)
        
        # Print performance metrics
        print(f"STT Duration: {stt_duration:.2f} seconds")
        print(f"LLM Response Duration: {llm_duration:.2f} seconds")
        print(f"TTS Duration: {tts_duration:.2f} seconds")
        print(f"Total Duration: {time.time() - start_time:.2f} seconds")
    
    def convert_pcm_to_wav(self, pcm_data, sample_rate, num_channels=1, sample_width=2):
        with io.BytesIO(pcm_data) as pcm_file:
            with wave.open(pcm_file, 'rb') as pcm_wave:
                with io.BytesIO() as wav_file:
                    wav_wave = wave.open(wav_file, 'wb')
                    wav_wave.setnchannels(num_channels)
                    wav_wave.setsampwidth(sample_width)
                    wav_wave.setframerate(sample_rate)
                    wav_wave.writeframes(pcm_data)
                    wav_wave.close()
                    return wav_file.getvalue()
