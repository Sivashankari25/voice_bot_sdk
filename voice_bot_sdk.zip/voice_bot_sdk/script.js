document.addEventListener('DOMContentLoaded', () => {
    const startRecordButton = document.getElementById('startRecord');
    const stopRecordButton = document.getElementById('stopRecord');
    const playAudioButton = document.getElementById('playAudio');
    const audioPlayback = document.getElementById('audioPlayback');

    let mediaRecorder;
    let audioChunks = [];
    let audioBlob;
    let audioUrl;

    // Set up media recorder
    const setupMediaRecorder = async () => {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        
        mediaRecorder.ondataavailable = event => {
            audioChunks.push(event.data);
        };
        
        mediaRecorder.onstop = async () => {
            audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
            audioChunks = [];
            
            // Send audio data to backend
            const formData = new FormData();
            formData.append('audio', audioBlob, 'recording.wav');

            try {
                const response = await fetch('http://localhost:5000/process', {
                    method: 'POST',
                    body: formData
                });

                if (response.ok) {
                    const audioResponseBlob = await response.blob();
                    audioUrl = URL.createObjectURL(audioResponseBlob);
                    audioPlayback.src = audioUrl;
                    playAudioButton.disabled = false;
                } else {
                    console.error('Failed to process audio:', response.statusText);
                }
            } catch (error) {
                console.error('Error sending audio to server:', error);
            }
        };
    };

    // Start recording
    startRecordButton.addEventListener('click', () => {
        setupMediaRecorder().then(() => {
            mediaRecorder.start();
            startRecordButton.disabled = true;
            stopRecordButton.disabled = false;
        });
    });

    // Stop recording
    stopRecordButton.addEventListener('click', () => {
        mediaRecorder.stop();
        startRecordButton.disabled = false;
        stopRecordButton.disabled = true;
    });

    // Play audio
    playAudioButton.addEventListener('click', () => {
        audioPlayback.play();
    });
});
