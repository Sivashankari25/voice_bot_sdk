# examples/example.py
import asyncio
import pyaudio
from sdk.conversation import ConversationManager

def main():
    # Configuration (replace with your actual API keys and prompts)
    stt_config = {'api_key': '87c2c23e1103b91a912cdf92307dbdd3e1717477'}
    tts_config = {'api_key': '7ec61e1d138654c36bc124d4ba61e6da22631aa9'}
    llm_config = {'api_key': 'sk-proj-P1fwSOdmS0twqdJEHkUuT3BlbkFJyIn35kROeetTnSaa99Vu', 'system_prompt': 'You are a helpful assistant.'}

    # Initialize conversation manager
    conversation_manager = ConversationManager(stt_config, tts_config, llm_config)

    # Audio stream setup
    p = pyaudio.PyAudio()
    input_stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, input=True, frames_per_buffer=1024)
    output_stream = p.open(format=pyaudio.paInt16, channels=1, rate=16000, output=True)

    # Run the conversation manager
    try:
        asyncio.run(conversation_manager.handle_conversation(input_stream, output_stream))
    finally:
        input_stream.stop_stream()
        input_stream.close()
        output_stream.stop_stream()
        output_stream.close()
        p.terminate()

if __name__ == "__main__":
    main()
